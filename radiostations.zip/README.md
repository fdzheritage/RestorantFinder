# Radiostations
Find restaurants in your area


# Tasks

Krasimir
+ Read documentation for Zomato


Anna
+ Read documentation for Zomato


Francisco




## API LINKS
https://developers.zomato.com/documentation


# Recipes
https://www.food2fork.com/about/api

# Nutritional content
https://developer.edamam.com/


# Music Events

https://app.swaggerhub.com/apis/Bandsintown/PublicAPI/3.0.0


https://trashnothing.com/developer




